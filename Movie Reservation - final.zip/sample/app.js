var express 		= require('express'),
	app 			= express(),
	bodyParser 		= require('body-parser'),
	mongoose 		= require('mongoose'),
	methodOverride 	= require('method-override'),
	SeatsioClient 	= require('seatsio')

mongoose.connect("mongodb://localhost:27017/movieees",{useNewUrlParser: true,useUnifiedTopology: true }, );

// APP CONFIG
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true}));
app.set('view engine','ejs');
app.use(express.static("public"));
app.use(methodOverride("_method"));
app.set('useFindAndModify', false);


// MONGOOSE/MODEL CONFIG
var movieSchema = new mongoose.Schema({
	  title: String,
	  image: String,
	  genre: String,
	  plot: String,
	  schedule: String,
	price: String,
	cinenum: Number,
	seats: [],
	created: {type: Date,default:Date.now}
});

var Movie = mongoose.model("Movie", movieSchema);

var orderSchema = new mongoose.Schema({
	  title: String,
	  image: String,
	  genre: String,
	  plot: String,
	  schedule: String,
	price: String,
	cinenum: Number,
	seats: [],
	created: {type: Date,default:Date.now}
});

var Order = mongoose.model("Order", orderSchema);




//RESTFUL ROUTES


// LANDING ROUTE - ok
app.get("/", function(req,res){
	res.render("landing")
});
// SEARCH ALL MOVIES - OK
app.get("/home", function(req,res){
	Movie.find({}, function(err, allMovies) {
		if(err){
			console.log("ERROR!");
		} else {
			res.render("index", {movie: allMovies});
		};
	}).sort({schedule: 'descending'});
});


// CREATE MOVIE ROUTE - ok
app.get("/home/admin", function(req, res){
	res.render("admin");
});

app.post("/home", function(req, res){
	// create movie
	Movie.create(req.body.movie, function(err, newMovie){
		if(err){
			res.render("admin");
		} else {
			// then, redirect to the index
			res.redirect("/home");
		}
	});
	
});

// SHOW ROUTE
app.get("/home/:id", function(req, res){
  Movie.findById(req.params.id, function(err, foundCinema){
    if(err){
      res.redirect("/home");
    }else{
      res.render("show", {movie: foundCinema});
    }
  });
});

// RESERVE ROUTE - not ok
app.get("/home/admin", function(req, res){
	res.render("admin");
});

app.post("/home", function(req, res){
	// create movie
	Movie.create(req.body.movie, function(err, newMovie){
		if(err){
			res.render("admin");
		} else {
			// then, redirect to the index
			res.redirect("/home");
		}
	});
	
});

// SHOW ROUTE
app.get("/home/:id", function(req, res){
  Movie.findById(req.params.id, function(err, foundCinema){
    if(err){
      res.redirect("/home");
    }else{
      res.render("show", {movie: foundCinema});
    }
  });
});



// SEATS
// ORDER - ok
app.post('/reserve', function(req,res){
	console.log(req.body.order);
	var data = req.body.order;
	var seatArr = data.seats.split(",");
  Order.create({
	  title: data.title,
	  genre: data.genre,
	  plot: data.plot,
	  cinenum: data.cinenum,
	  schedule: data.schedule,
	  seats: seatArr,
	  price: data.price,
	  image: data.image
  }, function(err, newMovie){
      if(err){
      console.log(err);
    } else {
		console.log(newMovie)
      res.redirect("/reserve");
		

    }
  });	
});


app.get("/home/:id/order",function(req,res){
	
    Movie.findById(req.params.id, function(err, foundCinema){
      if(err){
        res.redirect("/home");
      }else{
		 console.log(foundCinema);
        res.render("seats", {movie : foundCinema});
		 
      }
    })
});

app.get("/reserve",function(req,res){
    Order.find({},function(err,allCinema){
      if(err){
        console.log(err);
      }else{
        res.render('reserve',{order:allCinema}) ;
      }
    }).sort({created: 'descending'});
});




// EDIT ROUTE - ok
app.get("/home/:id/edit",function(req,res){
    Movie.findById(req.params.id, function(err, foundCinema){
      if(err){
        res.redirect("/home");
      }else{
        res.render("edit", {movie: foundCinema});
      }
    });
});


// UPDATE ROUTE - ok

app.put("/home/:id",function(req,res){
  Order.findByIdAndUpdate(req.params.id, req.body.movie,function(err, updateCinema){
    if(err){
      res.redirect("/home")
    }else{
      res.redirect("/home/" + req.params.id);
    }
  });
});


//DELETE ROUTE
app.delete("/home/:id",function(req,res){
  Order.findByIdAndRemove(req.params.id,function(err){
    if(err){
      res.redirect("/home");
    }else{
      res.redirect("/reserve");
    }
  });
});

app.listen(process.env.PORT || 3000, process.env.IP, function(){
	console.log("Now serving your app")
});

process.on('unhandledRejection', function(err) {
    console.log(err);
});
